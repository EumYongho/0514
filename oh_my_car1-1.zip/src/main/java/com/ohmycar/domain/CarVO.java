package com.ohmycar.domain;

public class CarVO {

}
