package com.ohmycar.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import com.ohmycar.controller.UserControllerTest;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml",
	"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@Log4j
@WebAppConfiguration  // 웹 애플리케이션 환경 설정

public class UserControllerTest {
	@Autowired
    private WebApplicationContext ctx; // 웹 애플리케이션 컨텍스트 주입
    
    private MockMvc mockMvc; // MockMvc 객체

	
	@Before
    public void setup() {  
           // MockMvc 객체를 설정
   	 this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
    }
	
	@Test
	public void testDelete() throws Exception {
		String resultPage = mockMvc.perform(MockMvcRequestBuilders.post("/views/user/delete")
	   			.param("userId", "1"))
	                                   .andReturn().getModelAndView().getViewName();
	         	log.info(resultPage);
	   }

}
